import prompt
from random import choice, randint
from brain_games.scripts.brain_games import main as welcome_user

name = welcome_user()

def generate_number():
    return randint(0, 100)


def summa(a ,b):
    summa = a + b
    return summa


def difference(a ,b):
    diff = a - b
    return diff


def multiplication(a ,b):
    multi = a * b
    return multi


# functions for calc task
funcs = (summa, difference, multiplication)

